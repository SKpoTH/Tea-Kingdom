
import styled from 'styled-components'

export default styled.div`
  max-width: 1000px;
  margin: auto;
`
