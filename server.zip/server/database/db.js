// mongodb db

module.exports = {
    //db: 'mongodb://localhost:27017/Tea-Kingdom'
    db: 'mongodb://tea:1eakingdom@ds249123.mlab.com:49123/heroku_m72fhxc7'
}